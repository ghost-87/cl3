package com.example.bhushangosavi.calculator;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static android.app.PendingIntent.getActivity;
import static java.lang.Math.*;

public class MainActivity extends AppCompatActivity {

    public double operand1;
    public double operand2;
    public String operation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button addButton = findViewById(R.id.addButton);
        Button subtractButton = findViewById(R.id.subtractButton);
        Button multiplyButton = findViewById(R.id.multiplyButton);
        Button divideButton = findViewById(R.id.divideButton);
        Button sinButton = findViewById(R.id.sinButton);
        Button cosButton = findViewById(R.id.cosButton);
        Button tanButton = findViewById(R.id.tanButton);
        Button sqrButton = findViewById(R.id.sqrButton);

        Button resultButton = (Button) findViewById(R.id.resultButton);
        Button clearButton = findViewById(R.id.clearButton);
        Button saveButton = findViewById(R.id.saveButton);
        Button loadButton = findViewById(R.id.loadButton);

//        Listeners for Operations

//        Add button -
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText operationStack = findViewById(R.id.operationStack);

                operand1 = Double.parseDouble(displayText.getText().toString());
                operation = "+";
                operationStack.setText(String.valueOf(operand1)+" "+operation);
                displayText.setText("");

            }
        });

        // Subtract button -
        subtractButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText operationStack = findViewById(R.id.operationStack);


                operand1 = Double.parseDouble(displayText.getText().toString());
                operation = "-";
                operationStack.setText(String.valueOf(operand1)+" "+operation);
                displayText.setText("");

            }
        });

        // multiply button -
        multiplyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText operationStack = findViewById(R.id.operationStack);


                operand1 = Double.parseDouble(displayText.getText().toString());
                operation = "*";
                operationStack.setText(String.valueOf(operand1)+" "+operation);
                displayText.setText("");

            }
        });

        // divide button -
        divideButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText operationStack = findViewById(R.id.operationStack);


                operand1 = Double.parseDouble(displayText.getText().toString());
                operation = "/";
                operationStack.setText(String.valueOf(operand1)+" "+operation);
                displayText.setText("");

            }
        });


        // sin button -
        sinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText operationStack = findViewById(R.id.operationStack);

                operation = "sin";
                operationStack.setText("sin(");
                displayText.setText("");

            }
        });


        // cps button -
        cosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText operationStack = findViewById(R.id.operationStack);
                operation = "cos";

                operationStack.setText("cos(");
                displayText.setText("");

            }
        });

        // tan button -
        tanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText operationStack = findViewById(R.id.operationStack);
                operation = "sin";

                operationStack.setText("tan(");
                displayText.setText("");

            }
        });

        // sqr button -
        sqrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText operationStack = findViewById(R.id.operationStack);
                operation = "sqr";

                operationStack.setText("sqr(");
                displayText.setText("");

            }
        });


//        Clear Button -
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText resultText = findViewById(R.id.resultText);
                EditText operationStack = findViewById(R.id.operationStack);
                displayText.setText("");
                resultText.setText("");
                operationStack.setText("");
                operation = "";
                operand1 = 0;
                operand2 = 0;

            }
        });


//       Calculate Result -
        resultButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText displayText = findViewById(R.id.displayText);
                EditText operationStack = findViewById(R.id.operationStack);
                EditText resultText = findViewById(R.id.resultText);

                if(operation == "sin" || operation == "cos" || operation == "tan" || operation == "sqr")
                {
                    operand1 = Double.parseDouble(displayText.getText().toString());
                    double result = TrigonometricCalculate(operation,operand1);
                    displayText.setText(String.valueOf(result));
                    operationStack.setText(operation+"("+ String.valueOf(operand1)+")");
                    resultText.setText(String.valueOf(result));

                }
                else{
                    operand2 = Double.parseDouble(displayText.getText().toString());
                    double result =  Calculate(operation,operand1,operand2);
                    displayText.setText(String.valueOf(result));
                    operationStack.setText(String.valueOf(operand1)+"" +operation+" "+ String.valueOf(operand2));
                    resultText.setText(String.valueOf(result));
                }

            }
        });

//     Save -
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Using Shared Preferences
                EditText operationStack = findViewById(R.id.operationStack);
                EditText resultext = findViewById(R.id.resultText);
                SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("operation",operationStack.getText().toString());
                editor.commit();

            }
        });

//            Save -
        loadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Using Shared Preferences
                EditText operationStack = findViewById(R.id.operationStack);
                EditText resultext = findViewById(R.id.resultText);

                SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
                String operation = getResources().getString(Integer.parseInt("operation"));

            }
        });



    }
    private double TrigonometricCalculate(String operation, double operand1) {
        switch (operation)
        {
            case "sin":
                return (sin(operand1));
            case "cos":
                return (cos(operand1));
            case "tan":
                return (tan(operand1));
            case "sqr":
                return (pow(operand1,2));
        }
        return 0;
    }

    private double Calculate(String operation, double operand1, double operand2) {

        switch (operation)
        {
            case "+":
                return (operand1+operand2);

            case "-":
                return (operand1-operand2);

            case "*":
                return (operand1*operand2);

            case "/":
                return (operand1/operand2);

            default:
                return 0;
        }
    }



}
