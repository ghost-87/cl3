package shubham.myapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static java.lang.Math.*;


public class MainActivity extends AppCompatActivity {

    Button button1,button2,button3,button4,button5,button6,button7,button8,button9,
           button10,button11,button12,buttonadd,buttonsub,buttonmul,buttondiv,buttoneql,buttonSin,
           buttonCos,buttonTan,buttonCot,buttonSec,buttonCosec,buttonLog,buttonInverse,
            buttonSqrt,buttonExponent;

    EditText edt1;
    TextView Result;
    Double mvalueOne, mvalueTwo;

    float mValueOne, mValueTwo,final_Result;


    boolean mAddition,mSubtraction,mMultiply,mDivision,Sine,Cos,Tan,Cot,Cosec,Sec,Log,Inverse,
            Sqrt,Exponent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button5 = (Button) findViewById(R.id.button5);
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);
        button8 = (Button) findViewById(R.id.button8);
        button9 = (Button) findViewById(R.id.button9);
        button10 = (Button) findViewById(R.id.button10);
        button11 = (Button) findViewById(R.id.button11);
        button12 = (Button) findViewById(R.id.button12);
        buttonadd = (Button) findViewById(R.id.buttonadd);
        buttonsub = (Button) findViewById(R.id.buttonsub);
        buttonmul = (Button) findViewById(R.id.buttonmul);
        buttondiv = (Button) findViewById(R.id.buttondiv);
        buttoneql = (Button) findViewById(R.id.buttoneql);
        buttonSin = (Button) findViewById(R.id.buttonSine);
        buttonCos = (Button) findViewById(R.id.buttonCos);
        buttonTan = (Button) findViewById(R.id.buttonTan);
        buttonCot = (Button) findViewById(R.id.buttonCot);
        buttonSec = (Button) findViewById(R.id.buttonSec);
        buttonCosec = (Button) findViewById(R.id.buttonCosec);
        buttonInverse = (Button) findViewById(R.id.buttonInverse);
        buttonLog = (Button) findViewById(R.id.buttonLog);
        buttonSqrt = (Button) findViewById(R.id.buttonSqrt);
        buttonExponent = (Button) findViewById(R.id.buttonExponent);


        edt1 = (EditText) findViewById(R.id.edt1);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"2");
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"3");
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"4");
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"5");
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"6");
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"7");
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"8");
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"9");
            }
        });

        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+".");
            }
        });
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText(edt1.getText()+"0");
            }
        });

        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edt1.setText("");
            }
        });

        buttonadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edt1 == null)
                {
                    edt1.setText("");
                }
                else
                {
                    mValueOne = Float.parseFloat(edt1.getText()+"");
                    mAddition = true;
                    edt1.setText(null);
                }
            }
        });

        buttonsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mValueOne = Float.parseFloat(edt1.getText()+"");
                mSubtraction = true;
                edt1.setText(null);
            }
        });

        buttonmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mValueOne = Float.parseFloat(edt1.getText()+"");
                mMultiply = true;
                edt1.setText(null);
            }

        });

        buttondiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mValueOne = Float.parseFloat(edt1.getText()+"");
                mDivision = true;
                edt1.setText(null);
            }
        });

        buttonSin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Sine = true;
                edt1.setText(null);
            }
        });

        buttonCos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cos = true;
                edt1.setText(null);
            }
        });

        buttonTan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Tan = true;
                edt1.setText(null);
            }
        });

        buttonCot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cot = true;
                edt1.setText(null);
            }
        });

        buttonSec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Sec = true;
                edt1.setText(null);
            }
        });

        buttonCosec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cosec = true;
                edt1.setText(null);
            }
        });

        buttonInverse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Inverse = true;
                edt1.setText(null);
            }
        });

        buttonLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log = true;
                edt1.setText(null);
            }
        });

        buttonSqrt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Sqrt = true;
                edt1.setText(null);
            }
        });

        buttonExponent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mvalueOne = Double.parseDouble(edt1.getText()+"");
                Exponent = true;
                edt1.setText(null);
            }
        });


        buttoneql.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                mValueTwo = Float.parseFloat(edt1.getText()+"");

                if (mAddition == true)
                {
                    final_Result = mValueOne + mValueTwo;
                    edt1.setText(final_Result + "");
                    mAddition = false;
                }

                if (mSubtraction == true)
                {
                    edt1.setText(mValueOne - mValueTwo +"");
                    mSubtraction = false;
                }


                if (mMultiply == true)
                {
                    edt1.setText(mValueOne * mValueTwo +"");
                    mMultiply = false;
                }


                if (mDivision == true)
                {
                    edt1.setText(mValueOne / mValueTwo +"");
                    mDivision = false;
                }

                if(Sine == true)
                {
                    edt1.setText(Double.toString(sin(toRadians(mValueTwo))));
                    Sine = false;
                }

                if(Cos == true)
                {
                    edt1.setText(Double.toString(cos(toRadians(mValueTwo))));
                    Cos = false;
                }

                if(Tan == true)
                {
                    edt1.setText(Double.toString(tan(toRadians(mValueTwo))));
                    Tan = false;
                }

                if(Cot == true)
                {
                    edt1.setText(Double.toString(1/(tan(toRadians(mValueTwo)))));
                    Cot = false;
                }

                if(Sec == true)
                {
                    edt1.setText(Double.toString(1/(cos(toRadians(mValueTwo)))));
                    Sec = false;
                }

                if(Cosec == true)
                {
                    edt1.setText(Double.toString(1/(sin(toRadians(mValueTwo)))));
                    Cosec = false;
                }

                if(Inverse == true)
                {
                    final_Result = (1/mValueTwo);

                    edt1.setText(String.format("%.3f",final_Result));
                    Inverse = false;

                }

                if(Log == true)
                {
                    edt1.setText(Double.toString(log10(mValueTwo)));
                    Log = false;
                }

                if(Sqrt == true)
                {
                    edt1.setText(Double.toString(Math.sqrt(mValueTwo)));
                    Sqrt = false;
                }

                if(Exponent == true)
                {
                    mvalueTwo = Double.parseDouble(edt1.getText()+"");
                    edt1.setText(Double.toString(Math.pow(mvalueOne,mvalueTwo)));
                    Exponent = false;
                }

            }
        });



    }
}
