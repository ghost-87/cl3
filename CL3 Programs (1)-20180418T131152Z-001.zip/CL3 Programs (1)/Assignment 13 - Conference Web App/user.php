<?


class user{
    
    function user(){
        $this->name = "";
        $this->email = "";
        $this->designation = "author";
        $this->country = "India";
        $this->hotel = "Bronze";
    }
    
}